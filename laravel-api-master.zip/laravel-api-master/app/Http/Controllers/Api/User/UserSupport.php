<?php

namespace App\Http\Controllers\Api\User;

trait UserSupport
{

}

<?php

declare(strict_types=1);

namespace App\Factory\Permission;

abstract class PermissionManager
{
    //
}

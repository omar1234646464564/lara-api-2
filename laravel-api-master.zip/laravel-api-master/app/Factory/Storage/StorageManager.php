<?php

namespace App\Factory\Storage;

/**
 * Class StorageManager
 * @package App\Factory\Storage
 */
abstract class StorageManager
{

}

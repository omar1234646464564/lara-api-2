<?php

declare(strict_types=1);

namespace App\Factory\Logger;

/**
 * Class LoggerManager
 * @package App\Factory\Logger
 */
abstract class LoggerManager
{

}

<?php

namespace App\Client\Logger\Logger;

trait LoggerMainSupport
{

}

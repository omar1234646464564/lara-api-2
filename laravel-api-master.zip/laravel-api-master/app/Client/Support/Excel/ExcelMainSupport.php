<?php

namespace App\Client\Support\Excel;

trait ExcelMainSupport
{

}

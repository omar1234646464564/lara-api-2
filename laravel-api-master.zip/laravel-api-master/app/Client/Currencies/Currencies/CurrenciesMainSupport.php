<?php

namespace App\Client\Currencies\Currencies;

trait CurrenciesMainSupport
{

}

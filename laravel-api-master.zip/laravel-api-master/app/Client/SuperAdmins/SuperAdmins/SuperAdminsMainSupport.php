<?php

namespace App\Client\SuperAdmins\SuperAdmins;

trait SuperAdminsMainSupport
{

}

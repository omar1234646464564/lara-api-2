<?php

namespace App\Client\Countries\Countries;

trait CountriesMainSupport
{

}

<?php

namespace App\Client\Countries\Districts;

trait DistrictsMainSupport
{

}

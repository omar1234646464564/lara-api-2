<?php

namespace App\Client\Countries\Cities;

trait CitiesMainSupport
{

}

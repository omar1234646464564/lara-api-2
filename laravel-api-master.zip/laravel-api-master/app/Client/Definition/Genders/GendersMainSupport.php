<?php

namespace App\Client\Definition\Genders;

trait GendersMainSupport
{
}

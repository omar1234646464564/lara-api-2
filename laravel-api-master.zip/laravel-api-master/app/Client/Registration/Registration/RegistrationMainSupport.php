<?php

namespace App\Client\Registration\Registration;

trait RegistrationMainSupport
{

}

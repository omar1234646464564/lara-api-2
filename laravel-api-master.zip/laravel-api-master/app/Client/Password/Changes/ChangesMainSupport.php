<?php

namespace App\Client\Password\Changes;

trait ChangesMainSupport
{
}

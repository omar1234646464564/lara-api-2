<?php

namespace App\Client\User\Photos;

trait PhotosMainSupport
{

}

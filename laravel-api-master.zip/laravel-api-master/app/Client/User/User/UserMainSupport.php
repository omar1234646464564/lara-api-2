<?php

namespace App\Client\User\User;

trait UserMainSupport
{

}

<?php

namespace App\Client\User\Activations;

trait ActivationsMainSupport
{

}

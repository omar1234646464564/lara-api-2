<?php

namespace App\Client\Mix\TableChanges;

trait TableChangesMainSupport
{

}

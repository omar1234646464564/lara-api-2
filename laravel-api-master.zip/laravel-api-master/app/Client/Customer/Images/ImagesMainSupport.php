<?php

namespace App\Client\Customer\Images;

trait ImagesMainSupport
{

}

<?php

namespace App\Client\Customer\Contacts;

trait ContactsMainSupport
{

}

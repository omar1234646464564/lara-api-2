<?php

namespace App\Client\Customer\Ages;

trait AgesMainSupport
{

}

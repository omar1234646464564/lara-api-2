<?php

namespace App\Client\Customer\Genders;

trait GendersMainSupport
{

}

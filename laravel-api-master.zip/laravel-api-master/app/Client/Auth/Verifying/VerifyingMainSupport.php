<?php

namespace App\Client\Auth\Verifying;

trait VerifyingMainSupport
{

}

<?php

namespace App\Client\Auth\Login;

trait LoginMainSupport
{

}

<?php

namespace App\Client\Timezones\Timezones;

trait TimezonesMainSupport
{

}

<?php

namespace App\Client\Gate\Roles;

trait RolesMainSupport
{

}

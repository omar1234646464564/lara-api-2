<?php

namespace App\Client\Gate\Permissions;

trait PermissionsMainSupport
{

}

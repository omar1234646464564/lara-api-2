<?php

namespace App\Client\Localizations\Localizations;

trait LocalizationsMainSupport
{

}

<?php 

namespace App\Client\Localizations\Front; 

trait FrontMainSupport
{
}

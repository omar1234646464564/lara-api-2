<?php

namespace App\Client\Localizations\Language;

trait LanguageMainSupport
{

}
